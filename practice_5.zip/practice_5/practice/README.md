> Дешевые серверы в Германии для доступного интернета - [https://koara.cloud/](https://koara.cloud/)

---

# Шаблонизатор Pug и препоцессор Stylus на Webpack

Репозиторий был создан для решения двух последних лабороторных работ с использованием Webpack

Основан на [nrud69/template_pug](https://github.com/nrud69/template_pug)

## Давайте начнём

Снчала склонируйте репозиторий:

```bash
git clone https://github.com/mraliscoder/template_pug.git
```

После этого установите пакеты node_modules:
```bash
npm install
```

Далее запустите свой проект:
```bash
npm run serve
```

Страница откроется по адресу [http://localhost:9000](http://localhost:9000)
